import ForgotPassword from "./forgot-passwd.container";

export default ForgotPassword;