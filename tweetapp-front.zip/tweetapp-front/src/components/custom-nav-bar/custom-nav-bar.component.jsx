import React from 'react';
import './custom-nav-bar.styles.css';
import imgTweetLogo from '../../assets/images/twitter-logo-transparent.png';
import imgProfileEmpty from '../../assets/images/user.png';
import { pages } from '../../constants/strings';
import 'bootstrap/dist/js/bootstrap.bundle'
import { fetchLoggedInUserDetails } from './custom-nav-bar.helper';

export default function CustomNavBar(props) {

  const onLogout = () => {
    localStorage.clear();
    window.location.reload();
  };
  React.useEffect(() => {
    const initialise = async () => {
      try {
        props.showLoader('Initialising Data');
        let userDetails = await fetchLoggedInUserDetails();
        props.updateUserData(userDetails);
        props.hideLoader();
      } catch (err) {
        console.log(err);
        props.hideLoader();
      }
    };
    initialise();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);


  const onNavItemClick = target => {
    props.updateSelectedPage(target);
  };

  return (
    
    <div className="fixed-top" style={{backgroundColor:"black"}}  >
      <nav className="navbar navbar-expand-lg navbar-light  navbar_bg" style={{ paddingRight: 15 ,backgroundColor:"#00008B"}}>
        <img src={imgTweetLogo} alt="gerdau-logo" height={50} width={30} />
        <button className="appName homeLink remove_button_styling" onClick={() => onNavItemClick(pages.HOME)} ></button>
        <p className="appName d-none d-lg-block d-xl-block" style={{ fontSize: 16, marginRight: 20 }}>|</p>
        <button className="navbar-toggler toggler_icon remove_button_styling" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
          <span className="navbar-toggler-icon "></span>
        </button>
        <div className="collapse navbar-collapse justify-content-between" id="navbarNavDropdown">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item ">
              <a class="nav-link" style={{ color: "white", backgroundColor: props.selectedPage == pages.HOME && "#00308f" }} href="#" onClick={() => onNavItemClick(pages.HOME)} >HOME</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" style={{ color: "white", backgroundColor: props.selectedPage == pages.MY_TWEETS && "#00308f" }} href="#" onClick={() => onNavItemClick(pages.MY_TWEETS)} >MY TWEETS</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" style={{ color: "white", backgroundColor: props.selectedPage == pages.ALL_USERS && "#00308f" }} href="#" onClick={() => onNavItemClick(pages.ALL_USERS)} >USERS</a>
            </li>
          </ul>
        
          <div className="w-md-100">
           
              <button className="dd_page pt-1 pb-1 remove_button_styling" onClick={onLogout}>Log Out</button>
            {/* </div> */}
          </div>
        </div>
      </nav>
    </div>
  );
}
