export const BASE_URI ='http://localhost:7070';
export const BASE_TWEET_URL = '/api/v1.0/tweets'
export const FORGOT_PASSWD = '/api/v1.0/tweets/forgetPassword'
export const AUTHENTICATE = '/authenticate'; 
export const REGISTER = '/api/v1.0/tweets/register'; 
export const ALL_TWEETS = '/all'; 
export const ALL_USERS = '/api/v1.0/tweets/users/all'; 
export const GET_USER = "/api/v1.0/tweets/user/search/"